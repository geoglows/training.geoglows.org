Practice files for Aquifer Analyst, Part 2 of the training at training.geoglows.org

Two regions in California built from public data, for practice in My Data. They are not
in the app's Sample Data. Lengths are in feet.

Monterey County, a region with nine aquifers
  monterey-region.geojson     the outline of the county, from the US Census Bureau's
                              cartographic boundary file of counties (1:500,000, 2024)
  monterey-aquifers.geojson   the nine groundwater basins and subbasins of California DWR's
                              Bulletin 118 that lie wholly inside the county. aquifer_id is the
                              Bulletin 118 number and aquifer_name the subbasin's name:
    3-004.01   180/400 Foot Aquifer      107 wells
    3-004.02   East Side Aquifer          40 wells
    3-004.04   Forebay Aquifer            39 wells
    3-004.05   Upper Valley Aquifer       21 wells
    3-004.08   Seaside                    55 wells
    3-004.09   Langley Area               16 wells
    3-004.10   Monterey                   40 wells
    3-007      Carmel Valley              16 wells
    3-006      Lockwood Valley             0 wells
  monterey-wells.csv          334 monitoring wells in those aquifers that have water levels
                              in DWR's Periodic Groundwater Level Measurements, one at each place
                              (see Wells left out, below), with DWR's site code as the well ID,
                              the ground surface elevation DWR gives, and the Bulletin 118 number
                              of the subbasin DWR lists
  monterey-water-levels.csv   their 37,778 groundwater elevations, 1916 to 2026, one row
                              per measurement: the measurements DWR rates Good. 41 are on a
                              day the well already has a measurement. DWR's datastore has
                              1,165 more records that repeat one of these in every field,
                              which are left out.

Pajaro Valley, a single-unit region
  pajaro-region.geojson       the outline of the Pajaro Valley subbasin (Bulletin 118 3-002.01)
  pajaro-water-quality.csv    1,548 water samples from 149 wells inside it, 1971 to 2023,
                              from the Water Quality Portal (all collected by the USGS), one well
                              at each place (see Wells left out, below), one row per sample with
                              a column per parameter. Each row gives the well's site ID in the
                              portal, its name and its location, from which the import makes the
                              wells. Nitrate reported as the nitrate ion is converted to nitrate
                              as N. A result below the detection limit leaves its cell empty.

Wells left out

Aquifer Analyst takes one well at each place in an aquifer, because wells of one aquifer within
10 m of each other would be averaged into one value on a map. The sources have more than one well
at some places, mostly nested wells finished at different depths, and the files keep one.

Monterey County: 26 places, 29 wells left out with their 32,490 water levels. Each
place keeps the well whose water levels agree best with those of nearby wells in the same aquifer.
Every water level is compared with the level estimated for its date from up to 6 wells of the
aquifer within 8 km that stand alone and were measured within 45 days of it, weighted by the
inverse square of distance; the well with the smaller median difference (ignoring sign) is kept.
A well with fewer than 5 such comparisons is not scored. Depths are the ones DWR gives.

    aquifer            name                   site code                depth  median difference
    3-004.01  kept     13S02E32E005M          367589N1217757W001   1,650 ft    6.8 ft
              left out 22755                  367589N1217757W002   1,573 ft    7.1 ft
    3-004.01  kept     14S02E11A002M          367371N1217098W001     250 ft   18.4 ft
              left out 14S02E11A004M          367371N1217098W002     490 ft   19.1 ft
    3-004.01  kept     BORB15010              367207N1216805W001     395 ft    6.2 ft
              left out BORA15009              367207N1216806W001     225 ft   30.5 ft
    3-004.01  kept     CHEB21205              365550N1215465W001     295 ft    3.7 ft
              left out CHEA21208              365550N1215466W001     140 ft    7.6 ft
    3-004.01  kept     GZWA21202              364883N1214684W001     115 ft    1.3 ft
              left out GZWB21201              364883N1214684W002     300 ft    3.1 ft
    3-004.01  kept     RODA14455              367343N1216958W001     265 ft    5.7 ft
              left out RODB14456              367343N1216959W001     390 ft   21.9 ft
    3-004.02  kept     FALA22619              366927N1215940W001     370 ft    8.4 ft
              left out FALB22618              366928N1215941W001     680 ft   24.0 ft
    3-004.04  kept     1415                   363361N1212158W001     120 ft   10.4 ft
              left out 285                    363361N1212158W002    depth ?  4 measurements, too few to compare
    3-004.04  kept     HUDA21067              363485N1212756W001     130 ft    4.1 ft
              left out HUDB18467              363485N1212755W001     253 ft    4.9 ft
    3-004.04  kept     LosCochesA21314        363562N1213033W001      95 ft    7.4 ft
              left out LosCochesB21066        363562N1213033W002     280 ft    7.5 ft
              left out LosCochesC18449        363562N1213033W003     590 ft   10.7 ft
    3-004.08  kept     Camp Huffman (S)       366205N1217697W002    depth ?   28.1 ft
              left out Camp Huffman Deep      366205N1217697W001    depth ?   35.4 ft
    3-004.08  kept     FO-06-Shallow          365713N1217537W001     700 ft   67.5 ft
              left out FO-06-Deep             365713N1217536W001   1,100 ft   74.0 ft
    3-004.08  kept     MPWMD #FO-04-Deep      365947N1218289W001     580 ft   63.2 ft
              left out MPWMD #FO-04-Shallow   365947N1218288W001     320 ft   64.0 ft
    3-004.08  kept     MPWMD #FO-07 Deep      366251N1218045W002     850 ft    8.8 ft
              left out MPWMD #FO-07 Shallow   366251N1218045W001     650 ft   23.0 ft
    3-004.08  kept     MPWMD #FO-09-Deep      366380N1218276W002     840 ft    8.2 ft
              left out MPWMD #FO-09-Shallow   366380N1218276W001     660 ft   13.1 ft
    3-004.08  kept     MSC Shallow            366219N1218468W001     695 ft    6.8 ft
              left out MSC Deep               366219N1218468W002     865 ft   11.4 ft
    3-004.08  kept     PCA East Shallow       366255N1218380W001     410 ft    6.6 ft
              left out PCA East Deep          366255N1218380W002     710 ft   12.1 ft
    3-004.08  kept     Seaside Middle Deep    366235N1218170W001   1,080 ft    8.6 ft
              left out Seaside Middle Shall   366236N1218169W001     670 ft    9.6 ft
    3-004.10  kept     014S001E24L003M        366992N1218076W002   1,430 ft    7.2 ft
              left out 014S001E24L002M        366992N1218076W001   1,880 ft   28.1 ft
              left out 014S001E24L004M        366992N1218076W003   1,080 ft   32.1 ft
              left out 014S001E24L005M        366992N1218076W004     970 ft   19.4 ft
    3-004.10  kept     14S02E33E02            366729N1217614W001   1,760 ft   18.8 ft
              left out 14S02E33E01            366730N1217615W001   1,095 ft   58.3 ft
    3-004.10  kept     CDM MW-1 Beach         366521N1218236W001     140 ft    3.3 ft
              left out Sentinel MW #1         366521N1218236W002    depth ?   26.7 ft
    3-004.10  kept     FO-05-Shallow          365729N1217447W002     740 ft   13.0 ft
              left out FO-05-Deep             365729N1217447W001   1,187 ft   82.6 ft
    3-004.10  kept     MPWMD #FO-08-Shallow   366363N1218018W001     790 ft   11.8 ft
              left out MPWMD #FO-08-Deep      366363N1218018W002     950 ft   23.3 ft
    3-004.10  kept     MPWMD #FO-10-Shallow   366466N1218079W001     650 ft    9.0 ft
              left out MPWMD #FO-10-Deep      366466N1218079W002   1,420 ft    9.9 ft
    3-004.10  kept     MPWMD#FO-11D           366474N1217847W001   1,130 ft   20.6 ft
              left out MPWMD#FO-11S           366474N1217847W002     740 ft   39.9 ft
    3-004.10  kept     Robley Shallow North   365608N1217494W002     430 ft   13.1 ft
              left out Robley Deep (South)    365608N1217494W001     820 ft   65.9 ft

Pajaro Valley: 7 places, 12 wells left out with their 16 samples. Each place keeps the
shallowest well, by the depth the portal gives, as the app's water quality download does at its
first setting; where depths are missing or equal, the well with the most samples.

             station          site ID                  depth  samples
    kept     011S001E36G002M  USGS-365613121482502    depth ?    2 samples
    left out 011S001E36G001M  USGS-365613121482501      95 ft    1 sample
    kept     012S001E03H002M  USGS-365503121500802    depth ?   33 samples
    left out 012S001E03H001M  USGS-365503121500801    depth ?    2 samples
    kept     012S001E10R003M  USGS-365351121501103     100 ft    1 sample
    left out 012S001E10R001M  USGS-365351121501101     280 ft    1 sample
    left out 012S001E10R002M  USGS-365351121501102     240 ft    2 samples
    kept     012S001E11R003M  USGS-365355121491003     210 ft    1 sample
    left out 012S001E11R001M  USGS-365355121491001     600 ft    1 sample
    left out 012S001E11R002M  USGS-365355121491002     540 ft    1 sample
    kept     012S001E23R004M  USGS-365206121490003     180 ft    1 sample
    left out 012S001E23R002M  USGS-365206121490001     490 ft    1 sample
    left out 012S001E23R003M  USGS-365206121490002     280 ft    1 sample
    kept     012S002E18N004M  USGS-365259121474804     190 ft    2 samples
    left out 012S002E18N001M  USGS-365259121474801     760 ft    1 sample
    left out 012S002E18N002M  USGS-365259121474802     640 ft    2 samples
    left out 012S002E18N003M  USGS-365259121474803     290 ft    2 samples
    kept     012S002E31E002M  USGS-365206121474302     120 ft    1 sample
    left out 012S002E31E001M  USGS-365206121474301     170 ft    1 sample

Downloaded and built by tools/aquiferx-figures/make-practice.py in the training.geoglows.org
repository.
