Practice files for Aquifer Analyst, Part 2 of the training at training.geoglows.org

Southwest Utah, a region with three aquifers (Cedar Valley, Parowan Valley and
Escalante Valley-Beryl-Enterprise), in feet:
  sw-utah-region.geojson       the region outline
  sw-utah-aquifers.geojson     the aquifer outlines, named in a NAME attribute
  sw-utah-wells.csv            wells with long water level records, without ground elevations
  sw-utah-water-levels.csv     their water table elevations, one row per measurement

Upper Klamath, a single-unit region in Oregon, in feet:
  klamath-region.geojson       the region outline
  klamath-water-quality.csv    water quality samples, one row per sample, with each
                               well's name and location (the import creates the wells)

The data come from the USGS and the Oregon sample region that ship with the app.
