Practice files for Aquifer Analyst, Part 2 of the training at training.geoglows.org

Two regions in California built from public data, for practice in My Data. They are not
in the app's Sample Data. Lengths are in feet.

Monterey County, a region with nine aquifers
  monterey-region.geojson     the outline of the county, from the US Census Bureau's
                              cartographic boundary file of counties (1:500,000, 2024)
  monterey-aquifers.geojson   the nine groundwater basins and subbasins of California DWR's
                              Bulletin 118 that lie wholly inside the county. aquifer_id is the
                              Bulletin 118 number and aquifer_name the subbasin's name:
    3-004.01   180/400 Foot Aquifer      113 wells
    3-004.02   East Side Aquifer          41 wells
    3-004.04   Forebay Aquifer            43 wells
    3-004.05   Upper Valley Aquifer       21 wells
    3-004.08   Seaside                    63 wells
    3-004.09   Langley Area               16 wells
    3-004.10   Monterey                   50 wells
    3-007      Carmel Valley              16 wells
    3-006      Lockwood Valley             0 wells
  monterey-wells.csv          the 363 monitoring wells in those aquifers that have water
                              levels in DWR's Periodic Groundwater Level Measurements, with
                              DWR's site code as the well ID, the ground surface elevation DWR
                              gives, the well depth DWR gives for 325 of them, and the
                              Bulletin 118 number of the subbasin DWR lists
  monterey-water-levels.csv   their 70,268 groundwater elevations, 1916 to 2026, one row
                              per measurement: the measurements DWR rates Good. 70 are on a
                              day the well already has a measurement. DWR's datastore has
                              2,537 more records that repeat one of these in every field,
                              which are left out.

Pajaro Valley, a single-unit region
  pajaro-region.geojson       the outline of the Pajaro Valley subbasin (Bulletin 118 3-002.01)
  pajaro-water-quality.csv    1,564 water samples from 161 wells inside it, 1971 to 2023,
                              from the Water Quality Portal (all collected by the USGS), one row
                              per sample with a column per parameter. Each row gives the well's
                              site ID in the portal, its name, its location and, for 103
                              of the wells, its depth, from which the import makes the wells.
                              Nitrate reported as the nitrate ion is converted to nitrate as N.
                              A result below the detection limit leaves its cell empty.

Downloaded and built by tools/aquiferx-figures/make-practice.py in the training.geoglows.org
repository.
